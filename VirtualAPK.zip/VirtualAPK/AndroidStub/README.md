# Android Framework Stub

该库主要是针对在 app 中无法直接调用 Android Framework 中很多隐藏的 API 而创造的一系列 stub 类用来欺骗编译器，从而避免了使用反射去调用造成性能损失
