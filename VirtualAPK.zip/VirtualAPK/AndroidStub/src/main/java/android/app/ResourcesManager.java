package android.app;

/**
 * Created by qiaopu on 2018/4/25.
 */
public class ResourcesManager {
    
    public static ResourcesManager getInstance() {
        throw new RuntimeException("Stub!");
    }
    
    public void appendLibAssetForMainAssetPath(String assetPath, String libAsset) {
        throw new RuntimeException("Stub!");
    }
    
}