package com.didi.virtualapk.demo.manager;

public class UserManager {

    public static int sUserId = 1;

}
