/*
 * Copyright (C) 2016 Baidu, Inc. All Rights Reserved.
 */
package dodola.anole;

import android.app.Application;
import android.content.Context;

import dodola.anole.lib.Anole;

/**
 * Created by sunpengfei on 16/9/15.
 */

public class AnoleApplication extends Application {
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);

    }

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
