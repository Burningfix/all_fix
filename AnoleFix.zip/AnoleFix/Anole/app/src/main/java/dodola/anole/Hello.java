/*
 * Copyright (C) 2016 Baidu, Inc. All Rights Reserved.
 */
package dodola.anole;

/**
 * Created by sunpengfei on 16/9/15.
 */

public class Hello {
    public String sayHello(){
        return "=======error======";
    }
}
