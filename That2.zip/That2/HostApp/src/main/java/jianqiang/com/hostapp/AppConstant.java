package jianqiang.com.hostapp;

/**
 * Created by jianqiang on 17/1/11.
 */
public class AppConstant {
    public static final int FROM_INTERNAL = 0;
    public static final int FROM_EXTERNAL = 1;

    public static final String EXTRA_DEX_PATH = "extra.dex.path";
    public static final String EXTRA_CLASS = "extra.class";

}
