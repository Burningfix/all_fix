# AndroidHotFixExamples

Most code copy from [https://github.com/simpleton/dalvik_patch](https://github.com/simpleton/dalvik_patch)

## HotFix Projects

下面的两个方案都是参考了[腾讯QZone的方案](https://zhuanlan.zhihu.com/p/20308548)

百度的同学的实现 [HotFix](https://github.com/dodola/HotFix)

点评的同学的实现 [Nuwa](https://github.com/jasonross/Nuwa)


## Liscense

WTF Liscense
