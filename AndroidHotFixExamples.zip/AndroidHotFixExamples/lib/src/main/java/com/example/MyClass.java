package com.example;

public class MyClass {
    public void test1() {
        System.out.println("---------------MyClass.test1()");
    }
}
