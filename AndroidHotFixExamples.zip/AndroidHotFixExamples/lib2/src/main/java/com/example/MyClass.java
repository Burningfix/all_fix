package com.example;

/**
 * Created by bruce on 11/14/15.
 */
public class MyClass {
    public void test1() {
        System.out.println("-----------------MyClass.test1() from lib2");
    }
}
