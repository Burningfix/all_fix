package jianqiang.com.receivertestbetweenactivityandservice.data;

public interface IServiceInterface {
    public void play();
    public void stop();
}