package com.lody.legend.interfaces;

/**
 * @author Lody
 * @version 1.0
 */
public interface Restoreable {
    void restore();
}
