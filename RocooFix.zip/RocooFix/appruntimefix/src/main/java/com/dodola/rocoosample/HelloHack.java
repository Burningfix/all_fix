/*
 * Copyright (C) 2016 Baidu, Inc. All Rights Reserved.
 */
package com.dodola.rocoosample;

/**
 * Created by sunpengfei on 16/5/24.
 */
public class HelloHack {

    public String showHello() {
        return "Hello World";
    }
}
