package com.example.jianqiang.mypluginlibrary;

import android.content.pm.PackageInfo;

public class PluginItem {
    public PackageInfo packageInfo;
    public String pluginPath;

    public PluginItem() {
    }
}