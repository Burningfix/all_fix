package com.example.jianqiang.mypluginlibrary;

public class AppConstants {
    public static final String ACTION = "jianqiang.com.hostapp.VIEW";
    public static final String EXTRA_DEX_PATH = "extra.dex.path";
    public static final String EXTRA_CLASS = "extra.class";
}