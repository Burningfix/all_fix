package com.example.jianqiang.dp3_3;

import android.util.Log;

/**
 * Created by jianqiang on 16/8/6.
 */
public class Class1 implements Class1Interface {
    @Override
    public void doSomething() {
        Log.e("bao", "class1");
    }
}
