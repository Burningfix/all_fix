package com.example.jianqiang.dp3_3;

/**
 * Created by jianqiang on 16/8/6.
 */
public class Class2 implements Class2Interface {
    public void work() {
        System.out.println("class2");
    }
}
