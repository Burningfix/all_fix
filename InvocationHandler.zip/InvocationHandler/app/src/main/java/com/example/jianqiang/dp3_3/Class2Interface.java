package com.example.jianqiang.dp3_3;

/**
 * Created by jianqiang on 16/8/6.
 */
public interface Class2Interface {
    public void work();
}
