package zeus.test.hotfix;

/**
 * Created by jimor on 2017/3/15.
 */
public class TestHotfixActivity1 extends TestHotFixActivity{
}
