package zeus.test;

/**
 * Created by huangjian on 2016/12/6.
 * 这里把所有宿主向插件暴露的资源id都列举，其值应与public.xml中的配置保持一致
 */
public class StringConstant {
    public static final int string1 = 0x7f050024;
}
