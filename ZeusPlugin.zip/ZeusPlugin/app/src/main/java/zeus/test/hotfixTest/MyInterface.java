package zeus.test.hotfixTest;

/**
 * Created by jimor on 2017/3/15.
 */
public interface MyInterface {

    String getString();
}
