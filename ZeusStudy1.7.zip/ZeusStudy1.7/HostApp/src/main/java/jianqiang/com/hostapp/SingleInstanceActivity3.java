package jianqiang.com.hostapp;

import android.app.Activity;

public class SingleInstanceActivity3 extends Activity{
    // dummy
}
