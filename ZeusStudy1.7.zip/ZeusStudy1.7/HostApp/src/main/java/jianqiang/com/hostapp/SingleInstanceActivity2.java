package jianqiang.com.hostapp;

import android.app.Activity;

public class SingleInstanceActivity2 extends Activity{
    // dummy
}
