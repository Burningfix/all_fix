# 360RePlugin
Android 插件化开发 - 360 RePlugin 框架


> * 具体参照Demo
> * RePlugin 主程序
> * RePluginDemo 插件程序 => 后续新插件都以该插件Demo方式相同