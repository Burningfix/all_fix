package replugin.pro.base;

import com.qihoo360.replugin.RePluginApplication;

/**
 * Created by Administrator on 2018/6/5.
 */

public class BaseApplication extends RePluginApplication {
}
