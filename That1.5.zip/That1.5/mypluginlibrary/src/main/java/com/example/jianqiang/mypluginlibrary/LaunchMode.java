package com.example.jianqiang.mypluginlibrary;

public class LaunchMode {
    public final static int STANDARD = 0;
    public final static int SINGLETOP = 1;
    public final static int SINGLETASK = 2;
    public final static int SINGLEINSTANCE = 3;
}
