f=open('classes2.dex','w')
f.close()