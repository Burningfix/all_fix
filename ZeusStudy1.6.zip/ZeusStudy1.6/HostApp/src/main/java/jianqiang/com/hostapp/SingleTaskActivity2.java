package jianqiang.com.hostapp;

import android.app.Activity;

public class SingleTaskActivity2 extends Activity{
    // dummy
}
