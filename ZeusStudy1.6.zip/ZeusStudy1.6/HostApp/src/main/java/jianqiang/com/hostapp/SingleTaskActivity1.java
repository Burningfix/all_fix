package jianqiang.com.hostapp;

import android.app.Activity;

public class SingleTaskActivity1 extends Activity{
    // dummy
}
