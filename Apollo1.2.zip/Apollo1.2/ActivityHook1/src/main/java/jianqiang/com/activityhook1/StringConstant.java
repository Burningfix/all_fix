package jianqiang.com.activityhook1;

/**
 * Created by huangjian on 2016/12/6.
 * 这里把所有宿主向插件暴露的资源id都列举，其值应与public.xml中的配置保持一致
 */
public class StringConstant {
    //这里要与public.xml保持一致, 这个值给插件使用
    public static final int string1 = 0x7f050024;
}
