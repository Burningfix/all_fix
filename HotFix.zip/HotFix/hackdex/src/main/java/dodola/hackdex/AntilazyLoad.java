/*
 * Copyright (C) 2015 Baidu, Inc. All Rights Reserved.
 */
package dodola.hackdex;

/**
 * Created by sunpengfei on 15/11/3.
 */
public class AntilazyLoad {
}
