/*
 * Copyright (C) 2015 Baidu, Inc. All Rights Reserved.
 */
package dodola.hotfix;


/**
 * Created by sunpengfei on 15/11/3.
 */
public class BugClass {

    public String bug() {
        return "bug class";
    }
}
