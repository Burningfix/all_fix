package com.example.jianqiang.mypluginlibrary;

public interface IMyInterface {
    public int getCount();
}