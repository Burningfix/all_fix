# RePlugin Plugin Library

RePlugin Plugin Library是一个Java工程，由 **插件** 负责引入。

该类主要提供通过“Java反射”来调用主程序中 RePlugin Host Library 的相关接口，并提供“双向通信”的能力。

开发者需要依赖此Library，以让您的单品工程变成“插件”。请参见WiKi以了解接入方法。

有关RePlugin Plugin Library的详细描述，请访问我们的WiKi，以了解更多的内容。