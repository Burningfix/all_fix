#### 问题详细描述 Detailed description of the problem


#### 复现问题步骤 Steps to reproduce the problem
1. 
2. 

#### 其它重要信息 Other important information

replugin-host-lib/gradle Version:
rePlugin-plugin-lib/gradle Version:

Android API Version：
Android 手机型号&ROM(Phone model & ROM): 

#### Logcat上下文 Logcat context
