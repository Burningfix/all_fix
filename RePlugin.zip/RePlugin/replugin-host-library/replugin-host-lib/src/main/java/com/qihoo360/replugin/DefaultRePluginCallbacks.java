package com.qihoo360.replugin;

import android.content.Context;

/**
 * @deprecated Use RePluginCallbacks instead
 * @see RePluginCallbacks
 * @author RePlugin Team
 */

public class DefaultRePluginCallbacks extends RePluginCallbacks {

    /**
     * @deprecated Use RePluginCallbacks instead
     * @see RePluginCallbacks#RePluginCallbacks(Context)
     */
    public DefaultRePluginCallbacks(Context context) {
        super(context);
    }
}
