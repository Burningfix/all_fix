# RePlugin Host Library

RePlugin Host Library是一个Java工程，由 **主程序** 负责引入。

几乎所有和RePlugin相关的代码都在其中，是核心工程。

开发者需要依赖此Library，以实现对RePlugin的接入。请参见WiKi以了解接入方法。

有关RePlugin Host Library的详细描述，请访问我们的WiKi，以了解更多的内容。