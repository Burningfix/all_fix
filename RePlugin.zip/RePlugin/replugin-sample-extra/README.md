# replugin-sample-extra 中是一些更高级的示例

其中，replugin-sample-extra/fresco 是对 Fresco 的使用，实现了宿主和插件公用一份Fresco代码。

FrescoHost是宿主代码，FrescoPlugin是插件代码。
