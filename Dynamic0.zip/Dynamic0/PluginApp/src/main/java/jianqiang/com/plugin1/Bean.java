package jianqiang.com.plugin1;

public class Bean {
    private String name = "jianqiang";

    public String getName() {
        return name;
    }

    public void setName(String paramString) {
        this.name = paramString;
    }
}
