/*
 * Copyright (C) 2016 Baidu, Inc. All Rights Reserved.
 */
package dodola.deepin.proxydemo;

/**
 * Created by sunpengfei on 16/7/20.
 */

public interface IInterface {

    String getResult(String oriStr);
}
