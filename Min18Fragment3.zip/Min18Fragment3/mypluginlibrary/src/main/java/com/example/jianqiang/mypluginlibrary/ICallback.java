package com.example.jianqiang.mypluginlibrary;

/**
 * Created by jianqiang on 2018/2/27.
 */

public interface ICallback {
    void sendResult(String dexPath);
}