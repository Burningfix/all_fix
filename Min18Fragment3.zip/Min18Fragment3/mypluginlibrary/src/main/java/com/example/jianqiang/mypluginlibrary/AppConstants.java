package com.example.jianqiang.mypluginlibrary;

public class AppConstants {
    public static final String ACTION = "jianqiang.com.hostapp.VIEW";
    public static final String EXTRA_DEX_PATH = "extra.dex.path";
    public static final String EXTRA_CLASS = "extra.class";
    public static final String EXTRA_PACKANE_NAME = "extra.package.name";

    public static final String HOST_PACKAGE_NAME = "jianqiang.com.hostapp";
}