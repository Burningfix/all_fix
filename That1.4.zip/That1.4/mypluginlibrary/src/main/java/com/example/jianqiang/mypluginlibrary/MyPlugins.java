package com.example.jianqiang.mypluginlibrary;

import java.util.HashMap;

/**
 * Created by jianqiang on 17/1/11.
 */
public class MyPlugins {
    public final static HashMap<String, String> plugins = new HashMap<String, String>();
}
