package com.example.jianqiang.mypluginlibrary;

import android.content.Context;

/**
 * Created by baojianqiang on 16/2/23.
 */
public abstract interface IDynamic {
    String getStringForResId(Context context);
}
