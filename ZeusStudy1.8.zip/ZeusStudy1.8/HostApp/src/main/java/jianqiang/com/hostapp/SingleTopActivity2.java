package jianqiang.com.hostapp;

import android.app.Activity;

public class SingleTopActivity2 extends Activity{
    // dummy
}
