package jianqiang.com.hostapp;

import android.app.Activity;

public class SingleTaskActivity3 extends Activity{
    // dummy
}
