package com.jianqiang

class MyExtension {
    String message
}