package jianqiang.com.activityhook1;

import android.app.Activity;

/**
 * @author weishu
 * @date 16/3/29
 */
public class StubActivity extends Activity{
    // dummy
}
