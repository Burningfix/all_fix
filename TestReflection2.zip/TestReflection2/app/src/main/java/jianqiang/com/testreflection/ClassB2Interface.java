package jianqiang.com.testreflection;

public interface ClassB2Interface {
    void doSomething();
}
