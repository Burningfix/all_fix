package jianqiang.com.testreflection;

import android.util.Log;

class ClassB2 implements ClassB2Interface{
    public int id;

    public void doSomething() {
        Log.v("baobao", "ClassB2 doSomething");
    }
}
