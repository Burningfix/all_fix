package jianqiang.com.testreflection;

public class User {
    private final static int userId = 3;
    private final String name = "baobao";
}
