package com.example.jianqiang.mypluginlibrary;

/**
 * Created by baojianqiang on 16/2/23.
 */
public abstract interface Itest{
    public abstract void test();
}