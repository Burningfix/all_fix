package com.example.jianqiang.mypluginlibrary;

/**
 * Created by baojianqiang on 16/2/23.
 */
public abstract interface IBean {
    public abstract String getName();


    public abstract void setName(String paramString);
}
