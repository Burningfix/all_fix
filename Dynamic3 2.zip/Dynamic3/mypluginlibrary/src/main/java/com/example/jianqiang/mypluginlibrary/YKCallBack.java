package com.example.jianqiang.mypluginlibrary;

/**
 * Created by baojianqiang on 16/2/23.
 */
public abstract interface YKCallBack{
    public abstract void callback(IBean paramIBean);
}