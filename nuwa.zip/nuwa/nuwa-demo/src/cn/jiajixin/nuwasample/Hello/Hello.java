package cn.jiajixin.nuwasample.Hello;

/**
 * Created by jixin.jia on 15/11/5.
 */
public class Hello {
    public String say() {
        return "发现 bug";
    }
}
