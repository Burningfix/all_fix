/** Automatically generated file. DO NOT MODIFY */
package cn.jiajixin.nuwasample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}