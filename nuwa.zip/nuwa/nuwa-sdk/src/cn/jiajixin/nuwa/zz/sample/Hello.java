package cn.jiajixin.nuwa.zz.sample;

/**
 * Created by jixin.jia on 15/11/5.
 */
public class Hello {
    public String say() {
        return "有bug........";
//        return "============================\n======[bug解决]======\n============================";
    }
}
