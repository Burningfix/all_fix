package cn.jiajixin.nuwa.zz.sample;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import cn.jiajixin.nuwa.R;

public class MainActivity extends Activity {
    private TextView mTV = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mTV = (TextView) findViewById(R.id.textview);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnSS:
                if (mTV == null) {
                    mTV = (TextView) findViewById(R.id.textview);
                }
                mTV.setText(new Hello().say());
                break;
            case R.id.btnHotfix:
                if (mTV == null) {
                    mTV = (TextView) findViewById(R.id.textview);
                }
//                Nuwa.init(this);
                mTV.setText(new Hello().say());
                break;
            default:
                break;
        }
    }
}
