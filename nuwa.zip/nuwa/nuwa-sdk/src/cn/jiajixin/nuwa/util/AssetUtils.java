package cn.jiajixin.nuwa.util;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Created by jixin.jia on 15/10/31.
 */
public class AssetUtils {

    private static final String TAG = "sanbo.AssetUtils";

    /**
     * 拷贝assets文件到对应文件夹中.
     * 
     * @param context
     * @param assetName
     * @param dir
     * @return
     * @throws IOException
     */
    public static String copyAsset(Context context, String assetName, File dir) throws IOException {

        Log.e(TAG, "copyAsset.. " + assetName + "--->" + dir.toString());

        File outFile = new File(dir, assetName);
        if (!outFile.exists()) {
            AssetManager assetManager = context.getAssets();
            InputStream in = assetManager.open(assetName);
            OutputStream out = new FileOutputStream(outFile);
            copyFile(in, out);
            in.close();
            out.close();
        }
        Log.e(TAG, "copyAsset over... outFile:  " + outFile.getAbsolutePath());

        return outFile.getAbsolutePath();
    }

    private static void copyFile(InputStream in, OutputStream out) throws IOException {
        Log.e(TAG, "inside copyFile... ");

        byte[] buffer = new byte[1024];
        int read;
        while ((read = in.read(buffer)) != -1) {
            out.write(buffer, 0, read);
        }
        Log.e(TAG, " copyFile over... ");

    }
}
