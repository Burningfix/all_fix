package com.example.jianqiang.mypluginlibrary;

/**
 * Created by jianqiang on 17/1/11.
 */
public class AppConstants {
    public static final String EXTRA_PLUGIN_NAME = "extra.pluginname";
    public static final String EXTRA_CLASS = "extra.class";
}
