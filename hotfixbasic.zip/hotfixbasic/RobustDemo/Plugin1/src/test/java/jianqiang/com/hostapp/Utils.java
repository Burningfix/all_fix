package jianqiang.com.hostapp;

/**
 * @author weishu
 * @date 16/3/29
 */
public class Utils {

    public static int add(int a, int b) {
        return a - b;
    }
}
