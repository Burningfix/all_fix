//
//  Module2ViewController+Override.h
//  ProductC
//
//  Created by tianxuejun on 2017/3/8.
//  Copyright © 2017年 jianqiang. All rights reserved.
//

#import "Module2ViewController.h"

@interface Module2ViewController (Override)

@end
