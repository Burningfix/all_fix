//
//  APageViewController.h
//  MyApp
//
//  Created by jax on 13-9-2.
//  Copyright (c) 2013年 Bao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AppBaseViewController.h"

@interface Module1ViewController : AppBaseViewController

@end
