//
//  main.m
//  ProductA
//
//  Created by jianqiang on 17/3/7.
//  Copyright © 2017年 jianqiang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
