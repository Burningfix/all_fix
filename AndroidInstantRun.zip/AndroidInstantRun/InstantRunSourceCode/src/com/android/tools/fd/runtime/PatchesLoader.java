package com.android.tools.fd.runtime;

public abstract interface PatchesLoader {
    public abstract boolean load();
}