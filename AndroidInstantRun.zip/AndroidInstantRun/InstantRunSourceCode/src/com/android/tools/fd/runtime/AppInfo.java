package com.android.tools.fd.runtime;

/**
 * @Author Zheng Haibo (mochuan)
 * @Company Alibaba Group
 * @PersonalWebsite http://www.mobctrl.net
 * @version $Id: AppInfo.java, v 0.1 2016年6月28日 上午11:23:50 mochuan.zhb Exp $
 * @Description
 */
public class AppInfo {

    public static String applicationClass = null;
    public static String applicationId = "trip.taobao.com.testandroid";
    public static long token = -1066838687043834658L;
    public static boolean usingApkSplits = false;

}
