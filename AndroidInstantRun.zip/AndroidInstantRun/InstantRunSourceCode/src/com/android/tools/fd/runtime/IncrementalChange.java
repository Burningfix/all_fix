package com.android.tools.fd.runtime;

public abstract interface IncrementalChange {
    public abstract Object access$dispatch(String paramString, Object... paramVarArgs);
}