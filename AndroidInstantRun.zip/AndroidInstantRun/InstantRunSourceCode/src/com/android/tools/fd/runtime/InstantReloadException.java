package com.android.tools.fd.runtime;

public class InstantReloadException extends Exception {
    private static final long serialVersionUID = 6073979389720128019L;

    public InstantReloadException(String s) {
        super(s);
    }
}
