package com.tmall.wireless.test;

/**
 * Created by jingchaoqinjc on 17/4/4.
 */

public class TestImpl implements ITest {
    @Override
    public void test() {
        System.out.println("This is test");
    }
}
