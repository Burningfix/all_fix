package com.tmall.wireless.test;

/**
 * Created by jingchaoqinjc on 17/3/20.
 */

public class Test2 {

    public String string() {
        return "Hello World2";
    }

}
