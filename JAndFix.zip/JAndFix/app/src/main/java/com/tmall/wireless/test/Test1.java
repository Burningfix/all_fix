package com.tmall.wireless.test;

/**
 * Created by jingchaoqinjc on 17/3/20.
 */

public class Test1 {

    public String string() {
        return "Hello World1";
    }

    public String string2() {
        return "string2";
    }

}
