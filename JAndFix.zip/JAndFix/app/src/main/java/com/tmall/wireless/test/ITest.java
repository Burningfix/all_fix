package com.tmall.wireless.test;

/**
 * Created by jingchaoqinjc on 17/4/4.
 */

public interface ITest {

    void test();

}
