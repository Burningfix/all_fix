package com.tmall.wireless.jandfix;

import java.lang.reflect.Method;

/**
 * Created by jingchaoqinjc on 17/5/15.
 */

public class MethodReplaceArt4_0 implements IMethodReplace{
    @Override
    public void replace(Method src, Method dest) {

    }
}
