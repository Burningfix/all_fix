package com.tmall.wireless.jandfix;

/**
 * Created by jingchaoqinjc on 17/5/16.
 */
public final class MethodSizeCase {

    private void method1() {
    }

    private void method2() {
    }

    private void method3() {
    }

}
