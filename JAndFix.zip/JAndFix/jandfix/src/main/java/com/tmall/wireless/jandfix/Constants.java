package com.tmall.wireless.jandfix;

/**
 * Created by jingchaoqinjc on 17/5/18.
 */

public interface Constants {

    int INVALID_SIZE = -1;
}
