package com.yang.dump.util;

/**
 * Created by yangy on 2017/1/6.
 */
public class TypedValue {
	public static final String FILE_DEX = ".apk";
}

