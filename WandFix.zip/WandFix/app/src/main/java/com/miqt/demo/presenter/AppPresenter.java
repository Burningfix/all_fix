package com.miqt.demo.presenter;

public interface AppPresenter {
    String getStr();
}
