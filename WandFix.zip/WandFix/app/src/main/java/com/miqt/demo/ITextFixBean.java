package com.miqt.demo;

public interface ITextFixBean {
    void setStaticString(String str);

    String getStaticString();

    int getStaticInt();

    void setStaticInt(int num);

    int getFinalStaticInt();

    String getFinalStaticString();

    String getString();

    void setString(String str);

    int getInt();

    void setInt(int num);
}
