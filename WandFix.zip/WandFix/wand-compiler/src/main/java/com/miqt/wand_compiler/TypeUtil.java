package com.miqt.wand_compiler;

import com.squareup.javapoet.ClassName;

public class TypeUtil {
    public static final ClassName INJET = ClassName.get("com.miqt.wand", "Inject");
    public static final ClassName PROVIDER = ClassName.get("com.miqt.wand", "Provider");
}
