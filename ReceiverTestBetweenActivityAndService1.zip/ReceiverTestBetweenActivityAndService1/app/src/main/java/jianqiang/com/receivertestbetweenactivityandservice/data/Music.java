package jianqiang.com.receivertestbetweenactivityandservice.data;

public class Music {
    public String name;
    public String author;
    public String title;

    public Music(String name, String author, String title) {
        this.name = name;
        this.author = author;
        this.title = title;
    }
}