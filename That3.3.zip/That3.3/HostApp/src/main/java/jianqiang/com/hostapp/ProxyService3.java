package jianqiang.com.hostapp;

public class ProxyService3 extends ProxyService {
    private static final String TAG = "ProxyService3";
}

