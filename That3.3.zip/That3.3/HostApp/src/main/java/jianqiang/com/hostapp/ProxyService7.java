package jianqiang.com.hostapp;

public class ProxyService7 extends ProxyService {
    private static final String TAG = "ProxyService7";
}

