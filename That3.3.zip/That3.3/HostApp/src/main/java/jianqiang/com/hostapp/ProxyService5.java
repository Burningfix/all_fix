package jianqiang.com.hostapp;

public class ProxyService5 extends ProxyService {
    private static final String TAG = "ProxyService5";
}

