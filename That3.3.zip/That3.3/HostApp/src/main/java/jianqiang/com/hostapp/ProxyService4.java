package jianqiang.com.hostapp;

public class ProxyService4 extends ProxyService {
    private static final String TAG = "ProxyService4";
}

