package jianqiang.com.hostapp;

public class ProxyService2 extends ProxyService {
    private static final String TAG = "ProxyService2";
}

