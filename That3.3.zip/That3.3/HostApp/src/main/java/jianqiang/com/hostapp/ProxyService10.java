package jianqiang.com.hostapp;

public class ProxyService10 extends ProxyService {
    private static final String TAG = "ProxyService10";
}

