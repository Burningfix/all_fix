package jianqiang.com.hostapp;

public class ProxyService8 extends ProxyService {
    private static final String TAG = "ProxyService8";
}

