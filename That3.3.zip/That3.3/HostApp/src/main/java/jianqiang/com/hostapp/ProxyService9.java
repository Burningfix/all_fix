package jianqiang.com.hostapp;

public class ProxyService9 extends ProxyService {
    private static final String TAG = "ProxyService9";
}

