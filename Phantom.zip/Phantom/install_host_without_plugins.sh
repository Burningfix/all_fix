#!/usr/bin/env bash

./gradlew phantom-sample:host:clean
./gradlew phantom-sample:host:installDebug

