# phantom-plugin-lib

Phantom 插件依赖库，用来解决因剔除了公共库引起的 proguard 的问题。插件以 `provided` 方式依赖该模块