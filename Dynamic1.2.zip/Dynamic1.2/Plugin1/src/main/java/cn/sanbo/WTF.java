package cn.sanbo;

import android.content.Context;
import android.util.Log;

public class WTF {
    public static void init(Context context, String xxx) {
        Log.i("sanbo", "呦呦呦 , 欢迎调用init接口。参数:" + xxx);
    }
}
