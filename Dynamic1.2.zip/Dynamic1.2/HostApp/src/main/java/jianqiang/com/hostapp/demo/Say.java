package jianqiang.com.hostapp.demo;

public class Say {
    public static String hello() {
        return "有bug版本!";
    }
}
