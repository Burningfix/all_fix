package jianqiang.com.hostapp;

import android.app.Activity;

public class SingleInstanceActivity1 extends Activity{
    // dummy
}
