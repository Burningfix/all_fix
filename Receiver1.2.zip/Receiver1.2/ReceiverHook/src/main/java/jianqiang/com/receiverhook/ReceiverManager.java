package jianqiang.com.receiverhook;

import java.util.HashMap;

public class ReceiverManager {
    public static HashMap<String, String> pluginReceiverMappings;

    static {
        pluginReceiverMappings = new HashMap<String, String>();
    }
}