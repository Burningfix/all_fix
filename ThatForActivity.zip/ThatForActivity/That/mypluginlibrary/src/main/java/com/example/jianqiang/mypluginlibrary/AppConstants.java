package com.example.jianqiang.mypluginlibrary;

/**
 * Created by jianqiang on 17/1/11.
 */
public class AppConstants {
    public static final String PROXY_VIEW_ACTION = "jianqiang.com.hostapp.VIEW";

    public static final String EXTRA_DEX_PATH = "extra.dex.path";
    public static final String EXTRA_CLASS = "extra.class";
}
